import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calGUI {
    private JButton button0, button1, button2, button3, button4, button5, button6, button7, button8, button9;
    private JTextField numField1, numField2, resultField;
    private JButton addButton, subtractButton, multiplyButton, divideButton;
    private CalculatorApp calculator;

    public calGUI(CalculatorApp calculator) {
        this.calculator = calculator;

        JFrame frame = new JFrame("Calculator");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 2));

        // Create components
        numField1 = new JTextField();
        numField2 = new JTextField();
        resultField = new JTextField("Result");

        addButton = new JButton("Add");
        subtractButton = new JButton("Subtract");
        multiplyButton = new JButton("Multiply");
        divideButton = new JButton("Divide");

        // Add components to the frame
        frame.add(new JLabel("Number 1:"));
        frame.add(numField1);

        frame.add(new JLabel("Number 2:"));
        frame.add(numField2);

        frame.add(new JLabel("Result:"));
        frame.add(resultField);

        frame.add(addButton);
        frame.add(subtractButton);
        frame.add(multiplyButton);
        frame.add(divideButton);

        // Add action listeners
        addButton.addActionListener(e -> performOperation("+"));
        subtractButton.addActionListener(e -> performOperation("-"));
        multiplyButton.addActionListener(e -> performOperation("*"));
        divideButton.addActionListener(e -> performOperation("/"));

        // Make the frame visible
        frame.setVisible(true);
    }

    private void performOperation(String operator) {
        try {
            double num1 = Double.parseDouble(numField1.getText());
            double num2 = Double.parseDouble(numField2.getText());

            double result = calculator.performOperation(operator, num1, num2);

            resultField.setText(String.valueOf(result));
        } catch (NumberFormatException | ArithmeticException ex) {
            resultField.setText("Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new calGUI(new CalculatorApp()));
    }
}
