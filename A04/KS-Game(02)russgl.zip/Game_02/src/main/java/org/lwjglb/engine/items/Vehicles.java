package org.lwjglb.engine.items;

import java.util.Random;

public class Vehicles extends GameItem {
    Random r = new Random();

    //    public Vehicle(Mesh[] cubeMesh) {
//        super(cubeMesh);
//        this.setPosition(11.00f, 11.000f, 15 * r.nextFloat());
//        this.setVelocity(0.002f, 0.001f, 0.003f);
//        this.setRotation(new Quaternionf(2.6f, 4.7f, 3.9f, 0.0f));
//        this.setRotationVel(new Quaternionf(0.006f, 0.007f, 0.0009f, 0.0f));
//
//        this.setMeshes(cubeMesh);
//    }
    protected void Vehicle() {
    }

    public void setDefaultMesh() {

    }

    public void setDefaultPos() {

    }

    public float getFloat(float min, float max) {
        Float newFloat = r.nextFloat() * (max -min) - min;
        return newFloat;
    }

}