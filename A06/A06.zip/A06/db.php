<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "A06";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query the 'students' table
$sql = "SELECT * FROM students";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"]. " - Name: " . $row["name"]. " - Course: " . $row["course_name"]. " - Student Number: " . $row["student_number"]. "<br>";
    }
} else {
    echo "0 results";
}

// Note: No explicit $conn->close() is needed here

?>
