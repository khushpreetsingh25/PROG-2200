<?php

$validUsername = 'khushpreet'; // replace with your username
$validPasswordHash = '$2y$10$lcGXt1cOLNOBGYth1nhQYecyDw0aYhT9wJGc2NYdLaOFoekhOnmX'; // replace with your hashed password

?>
