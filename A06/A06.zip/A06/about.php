<!-- about.php -->

<?php
$activePage = 'about';
include 'header.php';
include 'nav.php';
?>

<main class="main-container">
    <section class="content-section">
        <h2>About Me</h2>
        <p>My name is Khushpreet Singh. I am an ITPR student at Nova Scotia Community College.</p>
    </section>
    <!-- Add more sections as needed for your content -->
</main>

<?php include 'footer.php'; ?>
