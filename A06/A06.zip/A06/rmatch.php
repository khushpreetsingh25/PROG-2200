<?php
$activePage = 'rmatch';
include 'header.php';
include 'nav.php';
?>

<main class="main-container">
    <section class="content-section">
        <h2>RMatch</h2>
        <div class="rmatch-container">
            <!-- Display the list of names -->
            <h3>List of Names:</h3>
            <ul>
                <?php
                $names = array("Khushpreet", "David", "Sharla", "Martha", "Mike");

                foreach ($names as $name) {
                    echo "<li>$name</li>";
                }
                ?>
            </ul>

            <!-- Include the logic to display a random name here -->
            <?php
            $randomName = $names[array_rand($names)];
            echo "<p>Random Name: $randomName</p>";
            ?>

            <!-- Button to display another random name -->
            <form method="post">
                <button type="submit" name="displayRandom">Display Another Random Name</button>
            </form>

            
        </div>
    </section>
    <!-- Add more sections as needed for your content -->
</main>

<?php include 'footer.php'; ?>
