<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to login page if not authenticated
    header("Location: login.php");
    exit();
}

// Logout logic
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Resume</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
        }

        main {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
        }

        p {
            color: #555;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .course-list {
            display: none;
            margin-top: 10px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 5px;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <header>
        <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    </header>

    <main>
        <p>Download my resume: <a href="RESUME_KHUSHPREET.docx" download>Resume</a></p>

        <!-- Logout form -->
        <form method="post">
            <button type="submit" name="logout">Logout</button>
        </form>

        <!-- Course list link and content -->
        <p>To see the list of courses <a href="javascript:void(0);" onclick="toggleCourseList()">click here</a>!</p>
        <div class="course-list" id="courseList">
            <ul>
                <li>PROG 2200</li>
                <li>INET 2005</li>
                <li>PROG 2100</li>
                <li>MOBI 3002</li>
                <li>INFT 2100</li>
                <li>COMM 3700</li>
            </ul>
        </div>

        <script>
            // Function to toggle the visibility of the course list
            function toggleCourseList() {
                var courseList = document.getElementById('courseList');
                courseList.style.display = (courseList.style.display === 'none') ? 'block' : 'none';
            }
        </script>
    </main>

</body>
</html>
