<?php
session_start();

if (!isset($_SESSION['username'])) {
    // Redirect to login page if not authenticated
    header("Location: login.php");
    exit();
}

// Logout logic
if (isset($_POST['logout'])) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Resume</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff; /* Set the text color to white */
            text-align: center;
            padding: 1em;
        }

        main {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #fff; /* Set the text color to white */
        }

        p {
            color: #555;
            margin-bottom: 15px;
        }

        a {
            color: #007bff;
            text-decoration: none;
            cursor: pointer;
        }

        a:hover {
            text-decoration: underline;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .course-list,
        .job-history {
            display: none;
            margin-top: 10px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 5px;
        }

        .toggle-link {
            color: #007bff;
            cursor: pointer;
        }

        .toggle-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <header>
        <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    </header>

    <main>
        <p>Download my resume: <a href="RESUME_KHUSHPREET.docx" download>Resume</a></p>

      

        <!-- Course list link and content -->
        <p>To see the list of courses <span class="toggle-link" onclick="toggleCourseList()">click here</span>!</p>
        <div class="course-list" id="courseList">
            <ul>
                <li>PROG 2200</li>
                <li>INET 2005</li>
                <li>PROG 2100</li>
                <li>MOBI 3002</li>
                <li>INFT 2100</li>
                <li>COMM 3700</li>
            </ul>
        </div>

        <!-- Job history link and content -->
        <p>To know my job history <span class="toggle-link" onclick="toggleJobHistory()">click here</span>!</p>
        <div class="job-history" id="jobHistory">
            <ul>
                <li>Worked at Tim Hortons</li>
                <li>Worked at Sobey's Warehouse</li>
                <!-- Add more job history entries as needed -->
            </ul>
        </div>
  <!-- Logout form -->
  <form method="post">
            <button type="submit" name="logout">Logout</button>
        </form>
        <script>
            // Function to toggle the visibility of the course list
            function toggleCourseList() {
                var courseList = document.getElementById('courseList');
                courseList.style.display = (courseList.style.display === 'none') ? 'block' : 'none';
            }

            // Function to toggle the visibility of the job history
            function toggleJobHistory() {
                var jobHistory = document.getElementById('jobHistory');
                jobHistory.style.display = (jobHistory.style.display === 'none') ? 'block' : 'none';
            }
        </script>
    </main>

</body>
</html>
