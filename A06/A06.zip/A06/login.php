<?php
session_start();

$activePage = 'login';
include 'header.php';
include 'nav.php';

// Hardcoded username and password (replace with your logic)
$validUsername = 'khushpreet';
$validPassword = 'khush';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredUsername = $_POST['username'];
    $enteredPassword = $_POST['password'];

    if ($enteredUsername === $validUsername && $enteredPassword === $validPassword) {
        // Authentication successful
        $_SESSION['username'] = $enteredUsername;
        header("Location: download_resume.php");
        exit();
    } else {
        $error = 'Invalid username or password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Add your styles and scripts here -->
    <style>
        /* Add your CSS styling from the previous code here */
        body {
            /* Your body styling */
        }

        .main-container {
            /* Your main container styling */
        }

        .content-section {
            /* Your content section styling */
        }

        .login-container {
            /* Your login container styling */
        }

        /* Add more styles as needed */
    </style>
</head>
<body>

<main class="main-container">
    <section class="content-section">
        <h2>Login</h2>
        <div class="login-container">
            <?php if (isset($error)) : ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <form action="login.php" method="post">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Login</button>
            </form>
        </div>
    </section>
    <!-- Add more sections as needed for your content -->
</main>

<?php include 'footer.php'; ?>

</body>
</html>
