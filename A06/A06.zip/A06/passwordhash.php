<?php

$password = 'khush';

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

echo $hashedPassword;

?>
