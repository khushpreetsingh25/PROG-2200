<!-- resume.php -->

<?php
$activePage = 'resume';
include 'header.php';
include 'nav.php';
?>

<main class="main-container">
    <section class="content-section">
        <h2>Resume</h2>
        <p><h1>Education:</h1>
        <br>Currently, I am pursuing my IT Programming Diploma from Nova Scotia Community College.</p>
    </section>
    <!-- Add more sections as needed for your content -->
</main>

<?php include 'footer.php'; ?>
