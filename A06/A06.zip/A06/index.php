<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$activePage = 'home';
include 'header.php';
include 'nav.php';
?>


<main class="main-container">
    <section class="content-section">
        <h2>Welcome to My Portfolio</h2>
        <p>Hello Everyone!<br>My name is Khushpreet Singh and I am an ITPR student at Nova Scotia Community College.<br>You can see other sections in the navigation bar. Just scroll through that to learn more about me!</p>
    </section>

    <!-- Chat Application Section -->
    <section class="content-section">
        <h2>Chat with Me</h2>

        <!-- Chat Application HTML -->
        <div id="page-wrap">
            <h2>jQuery/PHP Chat</h2>
            <p id="name-area"></p>
            <div id="chat-wrap">
                <div id="chat-area"></div>
            </div>
            <form id="send-message-area">
                <p>Your message: </p>
                <textarea id="sendie" maxlength='100'></textarea>
            </form>
        </div>

        <!-- Chat Application JavaScript -->
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="chat.js"></script>
        <script>
            var name = prompt("Enter your chat name:", "Guest");

            if (!name || name === ' ') {
                name = "Guest";
            }

            name = name.replace(/(<([^>]+)>)/ig, "");

            $("#name-area").html("You are: <span>" + name + "</span>");

            var chat = new Chat();

            $(function () {
                chat.getState();

                $("#sendie").keydown(function (event) {
                    var key = event.which;
                    if (key >= 33) {
                        var maxLength = $(this).attr("maxlength");
                        var length = this.value.length;
                        if (length >= maxLength) {
                            event.preventDefault();
                        }
                    }
                });

                $('#sendie').keyup(function (e) {
                    if (e.keyCode == 13) {
                        var text = $(this).val();
                        var maxLength = $(this).attr("maxlength");
                        var length = text.length;
                        if (length <= maxLength + 1) {
                            chat.send(text, name);
                            $(this).val("");
                        } else {
                            $(this).val(text.substring(0, maxLength));
                        }
                    }
                });
            });
        </script>
    </section>
    <!-- End of Chat Application Section -->

    <!-- Add more sections as needed for your content -->
</main>

<?php include 'footer.php'; ?>
