<?php
include 'db.php';

// Logout logic
if (isset($_POST['logout'])) {
    header("Location: index.php"); // Assuming 'index.php' is the home page of your portfolio
    exit();
}

// CREATE operation
if (isset($_POST['create'])) {
    $name = $_POST['name'];
    $course = $_POST['course'];
    $studentNumber = $_POST['studentNumber'];

    $sql = "INSERT INTO students (name, course_name, student_number) VALUES ('$name', '$course', '$studentNumber')";
    $conn->query($sql);
}

// READ operation
$sql = "SELECT * FROM students";
$result = $conn->query($sql);

// UPDATE operation
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $course = $_POST['course'];
    $studentNumber = $_POST['studentNumber'];

    // Using prepared statement to prevent SQL injection
    $stmt = $conn->prepare("UPDATE students SET name=?, course_name=?, student_number=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $course, $studentNumber, $id);

    $stmt->execute();
    $stmt->close();
}

// DELETE operation
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM students WHERE id=$id";
    $conn->query($sql);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demo</title>
    <!-- Bootstrap CSS for styling -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <!-- Display a form for creating a new entry -->
            <h2>Create Entry</h2>
            <form action="?t=<?php echo time(); ?>" method="post">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" name="name" required>
                </div>

                <div class="form-group">
                    <label for="course">Course:</label>
                    <input type="text" class="form-control" name="course" required>
                </div>

                <div class="form-group">
                    <label for="studentNumber">Student Number:</label>
                    <input type="text" class="form-control" name="studentNumber" required>
                </div>

                <button type="submit" class="btn btn-primary" name="create">Create</button>
            </form>
        </div>
        <div class="col-md-6">
            <!-- Display the table of entries -->
            <h2>Student Records</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Student Number</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                            <td>
                                <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a>
                                <button class="btn btn-primary" onclick="editEntry('<?php echo $row['id']; ?>', '<?php echo htmlspecialchars($row['name']); ?>', '<?php echo htmlspecialchars($row['course_name']); ?>', '<?php echo htmlspecialchars($row['student_number']); ?>')">Edit</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row mt-4">
        <!-- Display a form for updating an existing entry -->
        <div class="col-md-6">
            <h2>Edit Entry</h2>
            <form action="?t=<?php echo time(); ?>" method="post">
                <input type="hidden" name="id">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" name="name" required>
                </div>

                <div class="form-group">
                    <label for="course">Course:</label>
                    <input type="text" class="form-control" name="course" required>
                </div>

                <div class="form-group">
                    <label for="studentNumber">Student Number:</label>
                    <input type="text" class="form-control" name="studentNumber" required>
                </div>

                <button type="submit" class="btn btn-primary" name="update">Update</button>
            </form>
        </div>

        <!-- Logout form -->
        <div class="col-md-6">
            <form method="post">
                <button type="submit" class="btn btn-secondary" name="logout">Logout</button>
            </form>
        </div>
    </div>
</div>

<script>
    // Function to populate the form for updating an entry
    function editEntry(id, name, course, studentNumber) {
        document.querySelector('form [name="id"]').value = id;
        document.querySelector('form [name="name"]').value = name;
        document.querySelector('form [name="course"]').value = course;
        document.querySelector('form [name="studentNumber"]').value = studentNumber;
    }
</script>

<!-- Bootstrap JS for styling -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>
