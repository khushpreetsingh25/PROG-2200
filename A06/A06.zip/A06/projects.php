<?php
$activePage = 'projects';
include 'header.php';
include 'nav.php';
?>

<main class="main-container">
    <section class="content-section">
        <h2>Projects</h2>
        <!-- Add your project content here -->
        <div class="project">
            <img src="project1.png" alt="Project 1">
            <h3>Project 1: Rock Paper Scissors</h3>
            <p>This is a mobile game that we are developed.</p>
            <p>What I learned: Kotlin, java</p>
        </div>

        <div class="project">
            <img src="project2.png" alt="Project 2">
            <h3>Project 2: Wordle</h3>
            <p>This is also a mobile game that we developed.</p>
            <p>What I learned: kotlin, java</p>
        </div>

        <div class="project">
            <img src="project3.png" alt="Project 2">
            <h3>Project 3: Challenge Nova Scotia</h3>
            <p>In this project we brainstormed an Idea to overcome the problem of Food Insecurity in Nova Scotia</p>
            <p>What I learned: Project management skiils, Work under pressure</p>
        </div>
    </section>
    <!-- Add more sections as needed for your content -->
</main>

<?php include 'footer.php'; ?>
