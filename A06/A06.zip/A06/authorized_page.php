<?php
session_start();

if (!isset($_SESSION['username'])) {
    // User is not logged in, redirect to login page
    header("Location: login.php");
    exit();
}

$activePage = 'authorized';
include 'header.php';
include 'nav.php';
?>

<main class="main-container">
    <section class="content-section">
        <h2>Authorized Page</h2>
        <!-- Content for authorized users -->
        <p>Welcome, <?php echo $_SESSION['username']; ?>!</p>
        <!-- Add more sections as needed for your content -->
    </section>
</main>

<?php include 'footer.php'; ?>
// Add a log out link
<a href="logout.php">Logout</a>
