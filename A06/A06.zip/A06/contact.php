<!-- contact.php -->

<?php
$activePage = 'contact';
include 'header.php';
include 'nav.php';
?>

<main class="main-container">
    <section class="content-section">
        <h2>Contact Me</h2>
        <p>If you want to Contact me email me at : W0472139@nscc.ca</p>
    </section>
</main>

<?php include 'footer.php'; ?>
