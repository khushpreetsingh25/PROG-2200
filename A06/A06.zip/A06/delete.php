<!-- delete.php -->
<?php
include 'db.php';

// Check if the ID parameter is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve the record from the database
    $sql = "SELECT * FROM students WHERE id = $id";
    $result = $conn->query($sql);

    // Check if the record exists
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        // Redirect to the list of records if the record does not exist
        header("Location: index.php");
        exit();
    }
} else {
    // Redirect to the list of records if the ID parameter is not set
    header("Location: index.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Delete the record from the database
    $sql = "DELETE FROM students WHERE id = $id";
    $conn->query($sql);

    // Redirect to the list of records
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Record</title>
    <!-- Add your styles and scripts here -->
</head>
<body>

    <h2>Delete Record</h2>

    <!-- Display details of the record and confirm deletion -->
    <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
    <p><strong>Course Name:</strong> <?php echo $row['course_name']; ?></p>
    <p><strong>Student Number:</strong> <?php echo $row['student_number']; ?></p>

    <!-- Form to confirm deletion -->
    <form method="post" action="">
        <p>Are you sure you want to delete this record?</p>
        <button type="submit">Yes, Delete</button>
        <a href="index.php">Cancel</a>
    </form>

</body>
</html>
