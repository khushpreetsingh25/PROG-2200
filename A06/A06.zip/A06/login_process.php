<?php

include 'credentials.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $validUsername && password_verify($password, $validPasswordHash)) {
        // Authentication successful
        session_start();
        $_SESSION['username'] = $username;
        header("Location: download_resume.php");
        
        exit();
    } else {
        echo "Invalid username or password";
    }
}

?>
