<!-- view.php -->
<?php
include 'db.php';

// Check if the ID parameter is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve the record from the database
    $sql = "SELECT * FROM students WHERE id = $id";
    $result = $conn->query($sql);

    // Check if the record exists
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        // Redirect to the list of records if the record does not exist
        header("Location: index.php");
        exit();
    }
} else {
    // Redirect to the list of records if the ID parameter is not set
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Record</title>
    <!-- Add your styles and scripts here -->
</head>
<body>

    <h2>View Record</h2>

    <!-- Display details of the record -->
    <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
    <p><strong>Course Name:</strong> <?php echo $row['course_name']; ?></p>
    <p><strong>Student Number:</strong> <?php echo $row['student_number']; ?></p>

    <!-- Link to go back to the list of records -->
    <p><a href="index.php">Back to List</a></p>

</body>
</html>
