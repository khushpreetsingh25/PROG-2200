<!-- nav.php -->

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<div class="nav-container">
    <nav>
        <?php if (empty($activePage)) $activePage = 'home'; ?>
        <a <?php if ($activePage == 'home') echo 'class="active"'; ?> href='./index.php'>Home</a>
        <a <?php if ($activePage == 'about') echo 'class="active"'; ?> href='./about.php'>About</a>
        <a <?php if ($activePage == 'resume') echo 'class="active"'; ?> href='./resume.php'>Resume</a>
        <a <?php if ($activePage == 'contact') echo 'class="active"'; ?> href='./contact.php'>Contact</a>
        <!-- Add Projects Link -->
        <a <?php if ($activePage == 'projects') echo 'class="active"'; ?> href='./projects.php'>Projects</a>
        <!-- Add Demo Link -->
        <a <?php if ($activePage == 'demo') echo 'class="active"'; ?> href='./demo.php'>Demo</a>
        <!-- Add Login Link -->
        <a <?php if ($activePage == 'rmatch') echo 'class="active"'; ?> href='./rmatch.php'>RMatch</a>
        <!-- Add Login Link -->
        <a <?php if ($activePage == 'login') echo 'class="active"'; ?> href='./login.php'>Login</a>
    </nav>
</div>
