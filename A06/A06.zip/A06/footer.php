<footer>
        <p>&copy; <?php echo date("Y"); ?>&nbsp;Khushpreet Singh</p>
    </footer>
</body>
</html>
