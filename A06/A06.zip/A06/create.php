<!-- create.php -->
<?php
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $courseName = $_POST['course_name'];
    $studentNumber = $_POST['student_number'];

    // Insert new record into the database
    $sql = "INSERT INTO students (name, course_name, student_number) VALUES ('$name', '$courseName', '$studentNumber')";
    $conn->query($sql);

    // Redirect to the list of records
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Record</title>
    <!-- Add your styles and scripts here -->
</head>
<body>

    <h2>Add New Record</h2>

    <!-- Form to add a new record -->
    <form method="post" action="">
        <label for="name">Name:</label>
        <input type="text" name="name" required>

        <label for="course_name">Course Name:</label>
        <input type="text" name="course_name" required>

        <label for="student_number">Student Number:</label>
        <input type="text" name="student_number" required>

        <button type="submit">Add Record</button>
    </form>

    <!-- Link to go back to the list of records -->
    <p><a href="index.php">Back to List</a></p>

</body>
</html>
