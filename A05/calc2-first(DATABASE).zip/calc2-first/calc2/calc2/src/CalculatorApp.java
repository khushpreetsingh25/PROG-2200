import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CalculatorApp {
    private static final Logger logger = LoggerFactory.getLogger(CalculatorApp.class);

    public CalculatorApp() {
    }

    public double add(double num1, double num2) {
        double result = num1 + num2;
        logger.info("{} + {} = {}", num1, num2, result);
        return result;
    }

    public double subtract(double num1, double num2) {
        double result = num1 - num2;
        logger.info("{} - {} = {}", num1, num2, result);
        return result;
    }

    public double multiply(double num1, double num2) {
        double result = num1 * num2;
        logger.info("{} * {} = {}", num1, num2, result);
        return result;
    }

    public double divide(double num1, double num2) {
        if (num2 != 0.0) {
            double result = num1 / num2;
            logger.info("{} / {} = {}", num1, num2, result);
            return result;
        } else {
            logger.error("Cannot divide by zero.");
            throw new ArithmeticException("Cannot divide by zero.");
        }
    }

    public double performOperation(String operator, double num1, double num2) {
        switch (operator) {
            case "+":
                return this.add(num1, num2);
            case "-":
                return this.subtract(num1, num2);
            case "*":
                return this.multiply(num1, num2);
            case "/":
                return this.divide(num1, num2);
            default:
                logger.error("Invalid operator: {}", operator);
                throw new IllegalArgumentException("Invalid operator");
        }
    }
}
