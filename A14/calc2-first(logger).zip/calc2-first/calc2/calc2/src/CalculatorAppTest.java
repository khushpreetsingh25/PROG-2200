import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorAppTest {

    @Test
    public void testAdd() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.add(3.5, 2.5);
        assertEquals(6.0, result, 0.0001); // Delta is used for double comparison
    }

    @Test
    public void testAddNegativeNumbers() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.add(-3.0, -2.0);
        assertEquals(-5.0, result, 0.0001);
    }

    @Test
    public void testAddZero() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.add(0.0, 5.0);
        assertEquals(5.0, result, 0.0001);
    }

    @Test
    public void testSubtract() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.subtract(5.0, 2.0);
        assertEquals(3.0, result, 0.0001);
    }

    @Test
    public void testSubtractNegativeNumbers() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.subtract(-3.0, -2.0);
        assertEquals(-1.0, result, 0.0001);
    }

    @Test
    public void testSubtractZero() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.subtract(5.0, 0.0);
        assertEquals(5.0, result, 0.0001);
    }

    @Test
    public void testMultiply() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.multiply(4.0, 2.5);
        assertEquals(10.0, result, 0.0001);
    }

    @Test
    public void testMultiplyByZero() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.multiply(5.0, 0.0);
        assertEquals(0.0, result, 0.0001);
    }

    @Test
    public void testMultiplyNegativeNumbers() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.multiply(-3.0, 2.0);
        assertEquals(-6.0, result, 0.0001);
    }

    @Test
    public void testDivide() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.divide(8.0, 2.0);
        assertEquals(4.0, result, 0.0001);
    }

    @Test
    public void testDivideByFraction() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.divide(10.0, 2.5);
        assertEquals(4.0, result, 0.0001);
    }

    @Test
    public void testDivideNegativeNumbers() {
        CalculatorApp calculator = new CalculatorApp();
        double result = calculator.divide(-6.0, -2.0);
        assertEquals(3.0, result, 0.0001);
    }

    @Test
    public void testDivideByZero() {
        CalculatorApp calculator = new CalculatorApp();
        assertThrows(ArithmeticException.class, () -> calculator.divide(5.0, 0.0));
    }
}
